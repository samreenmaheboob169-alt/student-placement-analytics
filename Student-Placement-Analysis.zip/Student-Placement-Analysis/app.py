import os
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

from placement_features import render_placement_features

st.set_page_config(
    page_title="Student Placement Intelligence",
    page_icon="🎓",
    layout="wide"
)

BASE_DIR = Path(__file__).parent
DEFAULT_DATA = BASE_DIR / "student_placement.csv"

st.title("🎓 Student Placement Analysis")
st.caption("Placement analytics, readiness scoring, and personalized skill-gap guidance")

@st.cache_data
def make_demo_data(n=300, seed=42):
    rng = np.random.default_rng(seed)
    data = pd.DataFrame({
        "Student_ID": [f"STU{i:03d}" for i in range(1, n + 1)],
        "Department": rng.choice(
            ["CSE", "IT", "ECE", "EEE", "Mechanical", "Civil"], n
        ),
        "CGPA": np.round(rng.uniform(5.0, 10.0, n), 2),
        "Aptitude_Score": rng.integers(30, 101, n),
        "Communication_Skills": rng.integers(30, 101, n),
        "Technical_Skills": rng.integers(30, 101, n),
        "Internships": rng.integers(0, 4, n),
        "Projects": rng.integers(1, 6, n),
        "Backlogs": rng.integers(0, 4, n),
    })
    score = (
        (data["CGPA"] - 5) * 10
        + data["Aptitude_Score"] * 0.20
        + data["Communication_Skills"] * 0.15
        + data["Technical_Skills"] * 0.20
        + data["Internships"] * 5
        + data["Projects"] * 2
        - data["Backlogs"] * 8
    )
    probability = 1 / (1 + np.exp(-(score - 40) / 10))
    data["Placed"] = (rng.random(n) < probability).astype(int)
    return data

st.sidebar.header("📂 Dataset")
uploaded = st.sidebar.file_uploader(
    "Upload your dataset (CSV or Excel)",
    type=["csv", "xlsx", "xls"]
)

if uploaded is not None:
    try:
        if uploaded.name.lower().endswith(".csv"):
            df = pd.read_csv(uploaded)
        else:
            df = pd.read_excel(uploaded)
        data_source = f"Uploaded: {uploaded.name}"
    except Exception as exc:
        st.error(f"Could not read the uploaded file: {exc}")
        st.stop()
elif DEFAULT_DATA.exists():
    df = pd.read_csv(DEFAULT_DATA)
    data_source = "Bundled sample dataset"
else:
    df = make_demo_data()
    data_source = "Generated demonstration dataset"
    df.to_csv(DEFAULT_DATA, index=False)

st.sidebar.success(data_source)
st.sidebar.write(f"Rows: {len(df):,} | Columns: {len(df.columns)}")

# Basic dataset validation
if df.empty:
    st.error("The dataset has no rows.")
    st.stop()

st.sidebar.header("🔎 Filters")
filtered = df.copy()
if "Department" in filtered.columns:
    departments = sorted(filtered["Department"].dropna().astype(str).unique())
    chosen = st.sidebar.multiselect(
        "Department", departments, default=departments
    )
    filtered = filtered[
        filtered["Department"].astype(str).isin(chosen)
    ]

if "Placed" in filtered.columns:
    placed_filter = st.sidebar.multiselect(
        "Placement status",
        options=[0, 1],
        default=[0, 1],
        format_func=lambda x: "Placed" if x == 1 else "Not placed"
    )
    numeric_placed = pd.to_numeric(filtered["Placed"], errors="coerce")
    filtered = filtered[numeric_placed.isin(placed_filter)]

st.subheader("📊 Placement Overview")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Students", f"{len(filtered):,}")

placed_count = 0
placement_rate = None
if "Placed" in filtered.columns:
    status = pd.to_numeric(filtered["Placed"], errors="coerce")
    placed_count = int((status == 1).sum())
    valid_count = int(status.isin([0, 1]).sum())
    placement_rate = placed_count / valid_count * 100 if valid_count else 0
    c2.metric("Placed Students", f"{placed_count:,}")
    c3.metric("Placement Rate", f"{placement_rate:.1f}%")
else:
    c2.metric("Placed Students", "N/A")
    c3.metric("Placement Rate", "N/A")

if "CGPA" in filtered.columns:
    cgpa = pd.to_numeric(filtered["CGPA"], errors="coerce")
    c4.metric("Average CGPA", f"{cgpa.mean():.2f}" if cgpa.notna().any() else "N/A")
else:
    c4.metric("Average CGPA", "N/A")

left, right = st.columns(2)
with left:
    st.subheader("Placement Distribution")
    if "Placed" in filtered.columns:
        chart_data = pd.to_numeric(filtered["Placed"], errors="coerce").map(
            {0: "Not placed", 1: "Placed"}
        ).value_counts()
        st.bar_chart(chart_data)
    else:
        st.info("Add a 'Placed' column coded 0/1 to view placement distribution.")

with right:
    st.subheader("Average CGPA by Department")
    if {"Department", "CGPA"}.issubset(filtered.columns):
        cgpa_data = filtered.copy()
        cgpa_data["CGPA"] = pd.to_numeric(cgpa_data["CGPA"], errors="coerce")
        st.bar_chart(cgpa_data.groupby("Department")["CGPA"].mean())
    else:
        st.info("Department and CGPA columns are needed for this chart.")

st.subheader("🗂️ Dataset Explorer")
search = st.text_input("Search displayed data", placeholder="Type a student ID or value")
view = filtered.copy()
if search:
    mask = view.astype(str).apply(
        lambda col: col.str.contains(search, case=False, na=False)
    ).any(axis=1)
    view = view[mask]
st.dataframe(view, use_container_width=True, hide_index=True)
st.download_button(
    "⬇️ Download filtered dataset as CSV",
    data=filtered.to_csv(index=False).encode("utf-8"),
    file_name="filtered_student_placement.csv",
    mime="text/csv"
)

st.divider()
render_placement_features(filtered)

st.divider()
st.caption(
    "Dataset note: the included records are synthetic demonstration data. "
    "They are not real student records, and the placement labels are generated "
    "from a simple illustrative rule. Do not treat them as real-world evidence."
)
