# Student Placement Analysis

A Streamlit dashboard for exploring student placement data, reviewing placement trends, calculating an illustrative placement readiness score, and generating rule-based skill improvement suggestions.

## Features
- Sample CSV dataset included
- Upload CSV or Excel datasets
- Filter by department and placement status
- Explore and download filtered records
- Placement statistics and charts
- Weighted placement readiness score
- Personalized skill gap recommendations
- Downloadable readiness report

## Setup
```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Dataset
The included `student_placement.csv` contains 300 synthetic demonstration records. The placement label is generated from an illustrative mathematical rule; it is not real placement data and should not be used to make claims about real-world prediction performance.

You can upload your own CSV or Excel dataset using the sidebar. Use anonymized data and never publish identifiable student information without authorization.

## Readiness score
The score uses configurable weighted normalized indicators. Categories are illustrative guidelines, not validated hiring criteria. Skill recommendations are rule-based.

## Future work
- Validate on a real, authorized dataset
- Compare ML models using held-out data and precision/recall/F1
- Add explainable predictions and a company eligibility matcher
