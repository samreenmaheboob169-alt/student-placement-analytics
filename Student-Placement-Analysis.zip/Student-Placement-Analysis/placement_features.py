import pandas as pd
import streamlit as st


def render_placement_features(df):
    st.header("🎯 Placement Intelligence")
    data = df.copy()

    numeric_columns = [
        col for col in data.columns
        if pd.api.types.is_numeric_dtype(data[col])
    ]
    if not numeric_columns:
        st.warning("No numeric columns found. Upload a dataset with numeric student indicators.")
        return

    options = ["None"] + numeric_columns

    def select_column(label, default=None):
        index = options.index(default) if default in options else 0
        selected = st.selectbox(label, options, index=index, key=f"feature_{label}")
        return None if selected == "None" else selected

    with st.expander("⚙️ Map your dataset columns", expanded=False):
        st.caption("Choose the columns matching your data. If a column is absent, select None.")
        cgpa = select_column("CGPA column", "CGPA")
        aptitude = select_column("Aptitude score column", "Aptitude_Score")
        communication = select_column("Communication score column", "Communication_Skills")
        technical = select_column("Technical score column", "Technical_Skills")
        internships = select_column("Internship count column", "Internships")
        projects = select_column("Projects count column", "Projects")
        backlogs = select_column("Backlogs count column", "Backlogs")

    # name: (column, weight, maximum, lower_is_better)
    config = {
        "CGPA": (cgpa, 0.25, 10, False),
        "Aptitude": (aptitude, 0.20, 100, False),
        "Communication": (communication, 0.15, 100, False),
        "Technical Skills": (technical, 0.20, 100, False),
        "Internships": (internships, 0.10, 3, False),
        "Projects": (projects, 0.05, 5, False),
        "Backlogs": (backlogs, 0.05, 3, True),
    }

    scores = {}
    for name, (column, weight, maximum, lower_is_better) in config.items():
        if column is None:
            continue
        values = pd.to_numeric(data[column], errors="coerce").clip(0, maximum)
        normalized = 100 - values / maximum * 100 if lower_is_better else values / maximum * 100
        scores[name] = normalized

    if not scores:
        st.info("Open 'Map your dataset columns' and select at least one feature.")
        return

    # Weighted mean: missing values are excluded per student, not treated as zero.
    numerator = pd.Series(0.0, index=data.index)
    denominator = pd.Series(0.0, index=data.index)
    for name, values in scores.items():
        weight = config[name][1]
        valid = values.notna()
        numerator += values.fillna(0) * weight
        denominator += valid.astype(float) * weight

    data["Readiness_Score"] = numerator.div(denominator.where(denominator > 0)).round(2)

    def classify(value):
        if pd.isna(value):
            return "Insufficient Data"
        if value >= 75:
            return "Ready"
        if value >= 50:
            return "Almost Ready"
        return "Needs Improvement"

    data["Readiness_Category"] = data["Readiness_Score"].apply(classify)
    valid_scores = data["Readiness_Score"].dropna()

    st.subheader("Placement Readiness Score")
    if valid_scores.empty:
        st.warning("There is not enough numeric data to calculate a score.")
        return

    a, b, c = st.columns(3)
    a.metric("Average Readiness", f"{valid_scores.mean():.1f}/100")
    b.metric("Ready Students", int((data["Readiness_Category"] == "Ready").sum()))
    c.metric("Needs Improvement", int((data["Readiness_Category"] == "Needs Improvement").sum()))

    st.caption("Weights and thresholds are configurable educational guidelines, not guarantees of placement.")
    report_columns = [c for c in ["Student_ID", "Department", "Readiness_Score", "Readiness_Category"] if c in data.columns]
    if not report_columns:
        report_columns = ["Readiness_Score", "Readiness_Category"]
    st.dataframe(
        data[report_columns].sort_values("Readiness_Score", ascending=False),
        use_container_width=True,
        hide_index=True
    )
    st.bar_chart(data["Readiness_Category"].value_counts())
    st.download_button(
        "Download readiness report",
        data=data.to_csv(index=False).encode("utf-8"),
        file_name="placement_readiness_report.csv",
        mime="text/csv",
        key="download_readiness"
    )

    st.divider()
    st.subheader("Personalized Skill Gap Analyzer")
    valid_indices = data.index[data["Readiness_Score"].notna()].tolist()
    if not valid_indices:
        st.info("No students have a calculable readiness score.")
        return

    def student_label(idx):
        if "Student_ID" in data.columns:
            identity = str(data.loc[idx, "Student_ID"])
        else:
            identity = f"Row {idx}"
        return f"{identity} — {data.loc[idx, 'Readiness_Score']:.1f}/100"

    selected = st.selectbox(
        "Select a student",
        valid_indices,
        format_func=student_label,
        key="skill_gap_student"
    )

    student_scores = {
        name: float(values.loc[selected])
        for name, values in scores.items()
        if pd.notna(values.loc[selected])
    }
    st.write(f"**Readiness score:** {data.loc[selected, 'Readiness_Score']:.1f}/100")
    st.bar_chart(pd.DataFrame({"Score": student_scores}))

    recommendations = {
        "CGPA": "Revise core subjects and strengthen fundamentals.",
        "Aptitude": "Practice quantitative aptitude and logical reasoning.",
        "Communication": "Practice presentations, group discussions, and mock interviews.",
        "Technical Skills": "Practice coding, core technical concepts, and problem-solving.",
        "Internships": "Look for internships, volunteering, or practical experience.",
        "Projects": "Build a practical project and document it on GitHub.",
        "Backlogs": "Prioritize pending subjects and seek academic support."
    }

    weak = sorted(student_scores.items(), key=lambda item: item[1])
    gaps = [(name, score) for name, score in weak if score < 70]
    st.markdown("#### Recommended improvements")
    if gaps:
        for name, score in gaps:
            st.warning(f"**{name}: {score:.1f}/100** — {recommendations[name]}")
    else:
        st.success("All available indicators are at least 70/100. Continue preparing for interviews.")

    st.markdown("#### Top three improvement priorities")
    for name, score in weak[:3]:
        st.write(f"- **{name}**: {score:.1f}/100")
    st.caption("This is a rule-based educational aid, not a validated hiring model.")
